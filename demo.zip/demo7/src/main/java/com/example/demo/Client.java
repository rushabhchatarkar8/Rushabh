package com.example.demo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Client {
	@JsonProperty("LookupID")
	private String lookupID;
	@JsonProperty("ContactFirstName")
	private String contactFirstName;
	@JsonProperty("ContactLastName")
	private String contactLastName;
	@JsonProperty("PolicyNumber")
	private String policyNumber;
	@JsonProperty("Name")
	private String name;
	@JsonProperty("Phone")
	private String phone;
	@JsonProperty("Email")
	private String email;
	@JsonProperty("Address")
	private Address address;
	@JsonProperty("Agent")
	private Agent agent;
	@JsonProperty("Underwriter")
	private Underwriter underwriter;

	@JsonProperty("Locations") // <-- Add this annotation to map "Locations" to "locations"
	private ArrayList<Location> locations;

	public String getLookupID() {
		return lookupID;
	}

	public void setLookupID(String lookupID) {
		this.lookupID = lookupID;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}

	public Underwriter getUnderwriter() {
		return underwriter;
	}

	public void setUnderwriter(Underwriter underwriter) {
		this.underwriter = underwriter;
	}

	public ArrayList<Location> getLocations() {
		return locations;
	}

	public void setLocations(ArrayList<Location> locations) {
		this.locations = locations;
	}

	// Add getter and setter methods
	// ...

}
//public class Client {
//	@JsonProperty("LookupID")
//	private String lookupID;
//	@JsonProperty("ContactFirstName")
//	private String contactFirstName;
//	@JsonProperty("ContactLastName")
//	private String contactLastName;
//	@JsonProperty("PolicyNumber")
//	private String policyNumber;
//	@JsonProperty("Name")
//	private String name;
//	@JsonProperty("Phone")
//	private String phone;
//	@JsonProperty("Email")
//	private String email;
//	@JsonProperty("Address")
//	private Address address;
//	@JsonProperty("Agent")
//	private Agent agent;
//
//	public String getLookupID() {
//		return lookupID;
//	}
//
//	public void setLookupID(String lookupID) {
//		this.lookupID = lookupID;
//	}
//
//	public String getContactFirstName() {
//		return contactFirstName;
//	}
//
//	public void setContactFirstName(String contactFirstName) {
//		this.contactFirstName = contactFirstName;
//	}
//
//	public String getContactLastName() {
//		return contactLastName;
//	}
//
//	public void setContactLastName(String contactLastName) {
//		this.contactLastName = contactLastName;
//	}
//
//	public String getPolicyNumber() {
//		return policyNumber;
//	}
//
//	public void setPolicyNumber(String policyNumber) {
//		this.policyNumber = policyNumber;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getPhone() {
//		return phone;
//	}
//
//	public void setPhone(String phone) {
//		this.phone = phone;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public Address getAddress() {
//		return address;
//	}
//
//	public void setAddress(Address address) {
//		this.address = address;
//	}
//
//	public Agent getAgent() {
//		return agent;
//	}
//
//	public void setAgent(Agent agent) {
//		this.agent = agent;
//	}
//
//	// Add getter and setter methods
//
//}
