package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@RestController
public class DataController {

	private final DataService dataService;
	private final Gson gson;

	@Autowired
	public DataController(DataService dataService, Gson gson) {
		this.dataService = dataService;
		this.gson = gson;
	}

	@PostMapping("/data")
	public ResponseEntity<String> processData(@RequestBody String jsonData) {
		try {

			if (jsonData == null) {
				throw new IllegalArgumentException("JSON Data Can't be null");
			}
			List<JsonObject> processedData = dataService.processJsonData(jsonData);
			String processedJson = gson.toJson(processedData);
			return ResponseEntity.ok(processedJson);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}
//	@PostMapping("/data")
//	public ResponseEntity<String> processData(@RequestBody String jsonData) {
//		try {
//			if (jsonData == null) {
//				throw new IllegalArgumentException("JSON Data Can't be null");
//			}
//			List<JsonObject> processedData = dataService.processJsonData(jsonData);
//			String processedJson = gson.toJson(processedData);
//			String jsonString = processedJson;
//			// Convert processedJson (String) to ImportClientRequest object using
//			// ObjectMapper
//			ObjectMapper objectMapper = new ObjectMapper();
//			ImportClientRequest importClientRequest = objectMapper.readValue(jsonString, ImportClientRequest.class);
//
//			System.out.println("DivisionLookupID: " + importClientRequest.getDivisionLookupID());
//			System.out.println("Client LookupID: " + importClientRequest.getClient().getLookupID());
//
//			return ResponseEntity.ok("Done");
//		} catch (Exception e) {
//			return ResponseEntity.badRequest().body(e.getMessage());
//		}
//	}
}
