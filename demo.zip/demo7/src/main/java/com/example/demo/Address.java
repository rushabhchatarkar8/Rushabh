package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Address {
	@JsonProperty("Country")
	private String country;
	@JsonProperty("Street1")
	private String street1;
	@JsonProperty("Street2")
	private String street2;
	@JsonProperty("City")
	private String city;
	@JsonProperty("Region1")
	private String region1;
	@JsonProperty("Region2")
	private String region2;
	@JsonProperty("Region3")
	private String region3;
	@JsonProperty("Region4")
	private String region4;
	@JsonProperty("ZipCode")
	private String zipCode;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStreet1() {
		return street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRegion1() {
		return region1;
	}

	public void setRegion1(String region1) {
		this.region1 = region1;
	}

	public String getRegion2() {
		return region2;
	}

	public void setRegion2(String region2) {
		this.region2 = region2;
	}

	public String getRegion3() {
		return region3;
	}

	public void setRegion3(String region3) {
		this.region3 = region3;
	}

	public String getRegion4() {
		return region4;
	}

	public void setRegion4(String region4) {
		this.region4 = region4;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	// Add getter and setter methods

}
