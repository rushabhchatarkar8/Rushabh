package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GenericField2 {
	@JsonProperty("Number")
	private String number;
	@JsonProperty("Key")
	private String key;
	@JsonProperty("GenericFieldValueType")
	private int genericFieldValueType;
	@JsonProperty("Text")
	private String text;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getGenericFieldValueType() {
		return genericFieldValueType;
	}

	public void setGenericFieldValueType(int genericFieldValueType) {
		this.genericFieldValueType = genericFieldValueType;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	// Add getter and setter methods

}
