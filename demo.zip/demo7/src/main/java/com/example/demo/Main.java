package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Main {
	public static void main(String[] args) {
		String jsonString = "{\r\n" + "    \"divisionLookupID\": \"AZ_UK\",\r\n" + "    \"client\": {\r\n"
				+ "        \"LookupID\": \"27251\",\r\n" + "        \"PolicyNumber\": \"SZ26218858\",\r\n"
				+ "        \"Name\": \"alice test new edit EUROSTAMPA UK LIMITED AND UNICORN GRAPHICS LTD AND GILMOUR & DEAN LTD\",\r\n"
				+ "        \"Address\": {\r\n" + "            \"Country\": \"GB\"\r\n" + "        },\r\n"
				+ "        \"Agent\": {\r\n" + "            \"AgencyCode\": \"96686\",\r\n"
				+ "            \"AgencyName\": \"D2 Corporate Solutions Ltd\",\r\n"
				+ "            \"AgentCode\": \"19747\",\r\n" + "            \"Address\": {}\r\n" + "        },\r\n"
				+ "        \"Locations\": [\r\n" + "            {\r\n" + "                \"LookupID\": \"38823\",\r\n"
				+ "                \"PolicyNumber\": \"SZ26218858\",\r\n" + "                \"Address\": {\r\n"
				+ "                    \"Country\": \"GB\",\r\n"
				+ "                    \"Street1\": \"test 24 CLYDEHOLM ROAD\",\r\n"
				+ "                    \"Street2\": \"\",\r\n" + "                    \"City\": \"GLASGOW\",\r\n"
				+ "                    \"Region1\": \"\",\r\n" + "                    \"ZipCode\": \"G14 0QQ\"\r\n"
				+ "                },\r\n"
				+ "                \"RenewalDate\": \"2023-03-28T15:08:58.8820749+01:00\",\r\n"
				+ "                \"Coverages\": [\r\n" + "                    {\r\n"
				+ "                        \"CoverageTypeLookup\": \"PD_TIV\",\r\n"
				+ "                        \"GenericFields\": [\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"8124000\",\r\n"
				+ "                                \"Key\": \"01. PD Building\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"20713528\",\r\n"
				+ "                                \"Key\": \"02. PD Content\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            }\r\n" + "                        ]\r\n" + "                    }\r\n"
				+ "                ]\r\n" + "            }\r\n" + "        ]\r\n" + "    }\r\n" + "}";

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			ImportClientRequest importClientRequest = objectMapper.readValue(jsonString, ImportClientRequest.class);
			System.out.println("DivisionLookupID: " + importClientRequest.getDivisionLookupID());
			System.out.println("Client LookupID: " + importClientRequest.getClient().getLookupID());
			System.out.println("Client PolicyNumber: " + importClientRequest.getClient().getPolicyNumber());
			System.out.println("Client PolicyName: " + importClientRequest.getClient().getName());
			System.out.println("Address country:" + importClientRequest.getClient().getAddress().getCountry());
			System.out.println("Client Location Address:" + importClientRequest.getClient().getAgent().getAgencyCode());
			// Access other fields as needed
			// Access the "RenewalDate" from the first location in the Locations list
			Location firstLocation = importClientRequest.getClient().getLocations().get(0);
			System.out.println("RenewalDate: " + firstLocation.getRenewalDate());

			// Print the agent information
			System.out.println("AgencyCode: " + importClientRequest.getClient().getAgent().getAgencyCode());
			System.out.println("AgencyName: " + importClientRequest.getClient().getAgent().getAgencyName());
			System.out.println("AgentCode: " + importClientRequest.getClient().getAgent().getAgentCode());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
