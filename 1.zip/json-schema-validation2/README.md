JSON Schema validation in Java
=============

Example project for my blog post: [JSON Schema validation in Java][1]

[1]:https://www.mscharhag.com/java/json-schema-validation