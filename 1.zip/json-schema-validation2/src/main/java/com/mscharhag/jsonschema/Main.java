package com.mscharhag.jsonschema;

import java.io.IOException;

public class Main {

	public static void main(String[] args) {

		try {
			Validator.main1();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
