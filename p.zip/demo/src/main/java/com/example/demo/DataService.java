package com.example.demo;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.json.JsonSanitizer;

import org.springframework.stereotype.Service;

@Service
public class DataService {

    private final Gson gson;

    public DataService(Gson gson) {
        this.gson = gson;
    }

    public String processJsonData(String jsonData) {
    	
        if (jsonData == null || jsonData.isEmpty()) {
            throw new IllegalArgumentException("JSON data cannot be null");
        }
    	
        try {
            // Sanitize the input JSON data
            String sanitizedData = JsonSanitizer.sanitize(jsonData);

            // Deserialize the sanitized JSON string into an array of JsonElements
            JsonElement[] elements = gson.fromJson(sanitizedData, JsonElement[].class);

        	
        	
        	
        	
            // Deserialize the input JSON string into an array of JsonElements
          //  JsonElement[] elements = gson.fromJson(jsonData, JsonElement[].class);

            // Create a new JSON object
            JsonObject jsonObject = new JsonObject();

            // Iterate through each element in the array
            for (int i = 0; i < elements.length; i++) {
                JsonObject elementObject = elements[i].getAsJsonObject();

                // Iterate through each key-value pair in the element object
                for (String key : elementObject.keySet()) {
                	
                	String cleanedKey = key.replace(".0", "");
                    // Split the key by '.' to get the nested structure
                    String[] keyParts = cleanedKey.split("\\.");

                    JsonObject currentObject = jsonObject;

                    // Create nested JSON objects based on the key structure
                    for (int j = 0; j < keyParts.length - 1; j++) {
                        String keyPart = keyParts[j];
                        if (!currentObject.has(keyPart)) {
                            JsonObject nestedObject = new JsonObject();
                            currentObject.add(keyPart, nestedObject);
                            currentObject = nestedObject;
                        } else {
                            currentObject = currentObject.getAsJsonObject(keyPart);
                        }
                    }

                    // Set the value of the innermost key
//                    currentObject.addProperty(keyParts[keyParts.length - 1], elementObject.get(key));
                 // Set the value of the innermost key
                    JsonElement value = elementObject.get(key);
                    if (value.isJsonPrimitive()) {
                        currentObject.addProperty(keyParts[keyParts.length - 1], value.getAsString());
                    } else {
                        currentObject.add(keyParts[keyParts.length - 1], value);
                    }

                }
            }

            // Convert the JSON object to a JSON string
            return gson.toJson(jsonObject);
//           
            
//            // Convert the JSON object to a JSON string
//            String processedData = gson.toJson(jsonObject);
//
//            // Sanitize the processed JSON data
//            String sanitizedData = JsonSanitizer.sanitize(processedData);
//
//            // Return the sanitized JSON data
//            return sanitizedData;

        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid JSON data");
        }
    }
}


//// Set the value of the innermost key
////currentObject.addProperty(keyParts[keyParts.length - 1], elementObject.get(key));
//// Set the value of the innermost key
//JsonElement value = elementObject.get(key);
//if (value.isJsonPrimitive()) {
//  currentObject.addProperty(keyParts[keyParts.length - 1], value.getAsString());
//} else {
//  currentObject.add(keyParts[keyParts.length - 1], value);
//}
//
//}


