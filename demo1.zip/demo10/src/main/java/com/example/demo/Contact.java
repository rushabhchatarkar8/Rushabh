package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Contact {
	@JsonProperty("CellPhone")
	private String cellPhone;
	@JsonProperty("CompanyName")
	private String companyName;
	@JsonProperty("Email")
	private String email;
	@JsonProperty("FirstName")
	private String firstName;
	@JsonProperty("HomePhone")
	private String homePhone;
	@JsonProperty("LastName")
	private String lastName;
	@JsonProperty("Occupation")
	private String occupation;
	@JsonProperty("UseCompanyName")
	private boolean useCompanyName;
	@JsonProperty("WorkPhone")
	private String workPhone;
	@JsonProperty("Location")
	private String location;

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public boolean isUseCompanyName() {
		return useCompanyName;
	}

	public void setUseCompanyName(boolean useCompanyName) {
		this.useCompanyName = useCompanyName;
	}

	public String getWorkPhone() {
		return workPhone;
	}

	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	// Add getter and setter methods

}
