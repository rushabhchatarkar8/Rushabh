package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class Coverage {

	@JsonProperty("CoverageReference")
	private String coverageReference;

	@JsonProperty("CoverageTypeLookup")
	private String coverageTypeLookup;
	@JsonProperty("GenericFields")
	private ArrayList<GenericField2> genericFields;

	public String getCoverageReference() {
		return coverageReference;
	}

	public void setCoverageReference(String coverageReference) {
		this.coverageReference = coverageReference;
	}

	public String getCoverageTypeLookup() {
		return coverageTypeLookup;
	}

	public void setCoverageTypeLookup(String coverageTypeLookup) {
		this.coverageTypeLookup = coverageTypeLookup;
	}

	public ArrayList<GenericField2> getGenericFields() {
		return genericFields;
	}

	public void setGenericFields(ArrayList<GenericField2> genericFields) {
		this.genericFields = genericFields;
	}

	// Add getter and setter methods

}
