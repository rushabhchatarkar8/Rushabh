package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.json.JsonSanitizer;

public class Main2 {
	public static void main(String[] args) {
		String jsonString = "{\r\n" + "    \"divisionLookupID\": \"AZ_UK\",\r\n" + "    \"client\": {\r\n"
				+ "        \"LookupID\": \"27251\",\r\n" + "        \"PolicyNumber\": \"SZ26218858\",\r\n"
				+ "        \"Name\": \"alice test new edit EUROSTAMPA UK LIMITED AND UNICORN GRAPHICS LTD AND GILMOUR & DEAN LTD\",\r\n"
				+ "        \"Address\": {\r\n" + "            \"Country\": \"GB\" \r\n" + "        },\r\n"
				+ "        \"Agent\": {\r\n" + "            \"AgencyCode\": \"96686\",\r\n"
				+ "            \"AgencyName\": \"D2 Corporate Solutions Ltd\",\r\n"
				+ "            \"AgentCode\": \"19747\",\r\n" + "            \"Address\": {},\r\n"
				+ "            \"AgentType\": \"Broker\"\r\n" + "        },\r\n" + "        \"Locations\": [\r\n"
				+ "            {\r\n" + "                \"LookupID\": \"38823\",\r\n"
				+ "                \"PolicyNumber\": \"SZ26218858\",\r\n" + "                \"Address\": {\r\n"
				+ "                    \"Country\": \"GB\",\r\n"
				+ "                    \"Street1\": \"test 24 CLYDEHOLM ROAD\",\r\n"
				+ "                    \"Street2\": \"\",\r\n" + "                    \"City\": \"GLASGOW\",\r\n"
				+ "                    \"Region1\": \"\",\r\n" + "                    \"ZipCode\": \"G14 0QQ\"\r\n"
				+ "                },\r\n"
				+ "                \"RenewalDate\": \"2023-03-28T15:08:58.8820749+01:00\",\r\n"
				+ "                \"Coverages\": [\r\n" + "                    {\r\n"
				+ "                        \"CoverageTypeLookup\": \"PD_TIV\",\r\n"
				+ "                        \"CoverageReference\":\"Coverage 1\",\r\n"
				+ "                        \"GenericFields\": [\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"8124000\",\r\n"
				+ "                                \"Key\": \"01. PD Building\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"20713528\",\r\n"
				+ "                                \"Key\": \"02. PD Content\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"3500000\",\r\n"
				+ "                                \"Key\": \"03. Stock & Supply\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"0\",\r\n"
				+ "                                \"Key\": \"04. PD Other\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Text\": \"\",\r\n"
				+ "                                \"Key\": \"05. PD Other Description\",\r\n"
				+ "                                \"GenericFieldValueType\": 0\r\n"
				+ "                            },\r\n"
				+ "                            {    /*This field is the sum of 1,2,3,4*/\r\n"
				+ "                                \"Number\": \"32337528\",\r\n"
				+ "                                \"Key\": \"06. TIV PD\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n"
				+ "                            {    /*Sum of all values in Global Business Section*/\r\n"
				+ "                                \"Number\": \"29000000\",\r\n"
				+ "                                \"Key\": \"07. TIV BI\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"12\",\r\n"
				+ "                                \"Key\": \"08. BI Base Period (Months)\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n"
				+ "                            {    /*This field is the sum of 6,7*/\r\n"
				+ "                                \"Number\": \"61337528\",\r\n"
				+ "                                \"Key\": \"09. TIV (PD + BI )\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            }\r\n" + "                        ]\r\n" + "                    },\r\n"
				+ "                    {\r\n" + "                        \"CoverageTypeLookup\": \"PD_TIV\",\r\n"
				+ "                        \"CoverageReference\":\"Coverage 2\",\r\n"
				+ "                        \"GenericFields\": [\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"18124000\",\r\n"
				+ "                                \"Key\": \"01. PD Building\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"120713528\",\r\n"
				+ "                                \"Key\": \"02. PD Content\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"13500000\",\r\n"
				+ "                                \"Key\": \"03. Stock & Supply\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"0\",\r\n"
				+ "                                \"Key\": \"04. PD Other\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Text\": \"\",\r\n"
				+ "                                \"Key\": \"05. PD Other Description\",\r\n"
				+ "                                \"GenericFieldValueType\": 0\r\n"
				+ "                            },\r\n"
				+ "                            {    /*This field is the sum of 1,2,3,4*/\r\n"
				+ "                                \"Number\": \"132337528\",\r\n"
				+ "                                \"Key\": \"06. TIV PD\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n"
				+ "                            {    /*Sum of all values in Global Business Section*/\r\n"
				+ "                                \"Number\": \"129000000\",\r\n"
				+ "                                \"Key\": \"07. TIV BI\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n" + "                            {\r\n"
				+ "                                \"Number\": \"12\",\r\n"
				+ "                                \"Key\": \"08. BI Base Period (Months)\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            },\r\n"
				+ "                            {    /*This field is the sum of 6,7*/\r\n"
				+ "                                \"Number\": \"161337528\",\r\n"
				+ "                                \"Key\": \"09. TIV (PD + BI )\",\r\n"
				+ "                                \"GenericFieldValueType\": 1\r\n"
				+ "                            }\r\n" + "                        ]\r\n" + "                    }\r\n"
				+ "                ]\r\n" + "            }\r\n" + "        ]\r\n" + "    }\r\n" + "}"; // Your JSON
																										// string here

		String sanitizedData = JsonSanitizer.sanitize(jsonString);

		try {
			ObjectMapper mapper = new ObjectMapper();

			Root dataWrapper = mapper.readValue(sanitizedData, Root.class);

			// Now you can access the data using the POJO classes
			System.out.println(dataWrapper.getClient().getName());
			// ... etc.

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
