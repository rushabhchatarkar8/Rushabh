package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.json.JsonSanitizer;

@RestController
public class DataController {

	private final DataService dataService;
	private final Gson gson;
	private final ObjectMapper objectMapper;

	@Autowired
	public DataController(DataService dataService, Gson gson, ObjectMapper objectMapper) {
		this.dataService = dataService;
		this.gson = gson;
		this.objectMapper = objectMapper;

	}

	@PostMapping("/client")
	public ResponseEntity<String> processData1(@RequestBody String jsonData) {
		try {
			if (jsonData == null) {
				throw new IllegalArgumentException("JSON Data Can't be null");
			}
			List<JsonObject> processedData = dataService.processJsonData(jsonData);
			String processedJson = gson.toJson(processedData);

			// Deserialize JSON into ImportClientRequest objects
			Root[] importClientRequests = objectMapper.readValue(processedJson,
					Root[].class);

			// Now you have the data in Java objects, and you can work with it as needed
			// For example, you can access individual ImportClientRequest objects in the
			// array:
			for (Root importClientRequest : importClientRequests) {
				// Access data from each ImportClientRequest object
//				String divisionLookupID = importClientRequest.getDivisionLookupID();
//				Client client = importClientRequest.getClient();
				// ... and so on
//				System.out.println("D.ID:"+divisionLookupID);
//				System.out.println("Client :"+client);
				System.out.println("Client LookupID: " + importClientRequest.getClient().getLookupID());

				System.out.println("DivisionLookupID: " + importClientRequest.getDivisionLookupID());
				System.out.println("Client LookupID: " + importClientRequest.getClient().getLookupID());
				System.out.println("Client PolicyNumber: " + importClientRequest.getClient().getPolicyNumber());
				System.out.println("Client PolicyName: " + importClientRequest.getClient().getName());
				System.out.println("Address country:" + importClientRequest.getClient().getAddress().getCountry());
				System.out.println(
						"Client Location Address:" + importClientRequest.getClient().getAgent().getAgencyCode());
				// Access other fields as needed
				// Access the "RenewalDate" from the first location in the Locations list
				Location firstLocation = importClientRequest.getClient().getLocations().get(0);
				System.out.println("RenewalDate: " + firstLocation.getRenewalDate());

				// Print the agent information
				System.out.println("AgencyCode: " + importClientRequest.getClient().getAgent().getAgencyCode());
				System.out.println("AgencyName: " + importClientRequest.getClient().getAgent().getAgencyName());
				System.out.println("AgentCode: " + importClientRequest.getClient().getAgent().getAgentCode());
			}

			return ResponseEntity.ok("JSON data processed successfully.");
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@PostMapping("/data")
	public ResponseEntity<String> processData(@RequestBody String jsonData) {
		try {

			if (jsonData == null) {
				throw new IllegalArgumentException("JSON Data Can't be null");
			}
			List<JsonObject> processedData = dataService.processJsonData(jsonData);
			String processedJson = gson.toJson(processedData);
			return ResponseEntity.ok(processedJson);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}
	@PostMapping("/import-client1")
	public ResponseEntity<String> importClient1(@RequestBody String jsonData) {
	    try {
	        if (jsonData == null) {
	            throw new IllegalArgumentException("JSON Data Can't be null");
	        }

	        // Remove the "inspection" field from the JSON string
	        JsonNode rootNode = new ObjectMapper().readTree(jsonData);
	        ((ObjectNode) rootNode).remove("inspection");
	        String jsonDataWithoutInspection = rootNode.toString();

	        String sanitizedData = JsonSanitizer.sanitize(jsonDataWithoutInspection);
	        ObjectMapper mapper = new ObjectMapper();

	        Root root = mapper.readValue(sanitizedData, Root.class);

	        // Now you can access the data using the POJO classes
	        System.out.println(root.getClient().getName());

	        // Process the data or do whatever you need to do with it
	        // ...

	        String processedJson = gson.toJson(root);
	        return ResponseEntity.ok(processedJson);
	    } catch (Exception e) {
	        return ResponseEntity.badRequest().body(e.getMessage());
	    }
	}

	@PostMapping("/import-client")
	public ResponseEntity<String> importClient(@RequestBody String jsonData) {
		try {

			if (jsonData == null) {
				throw new IllegalArgumentException("JSON Data Can't be null");
			}
			
			String sanitizedData = JsonSanitizer.sanitize(jsonData);
			ObjectMapper mapper = new ObjectMapper();

			Root root = mapper.readValue(sanitizedData, Root.class);

			// Now you can access the data using the POJO classes
			System.out.println(root.getClient().getName());

			String processedJson = gson.toJson(root);
			return ResponseEntity.ok(processedJson);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}
}

//ObjectMapper mapper = new ObjectMapper();
//
//ImportClientRequest dataWrapper = mapper.readValue(sanitizedData, ImportClientRequest.class);
//
//// Now you can access the data using the POJO classes
//System.out.println(dataWrapper.getClient().getName());

// @PostMapping("/data")
//	public ResponseEntity<String> processData(@RequestBody String jsonData) {
//		try {
//			if (jsonData == null) {
//				throw new IllegalArgumentException("JSON Data Can't be null");
//			}
//			List<JsonObject> processedData = dataService.processJsonData(jsonData);
//			String processedJson = gson.toJson(processedData);
//			String jsonString = processedJson;
//			// Convert processedJson (String) to ImportClientRequest object using
//			// ObjectMapper
//			ObjectMapper objectMapper = new ObjectMapper();
//			ImportClientRequest importClientRequest = objectMapper.readValue(jsonString, ImportClientRequest.class);
//
//			System.out.println("DivisionLookupID: " + importClientRequest.getDivisionLookupID());
//			System.out.println("Client LookupID: " + importClientRequest.getClient().getLookupID());
//
//			return ResponseEntity.ok("Done");
//		} catch (Exception e) {
//			return ResponseEntity.badRequest().body(e.getMessage());
//		}
//	}
