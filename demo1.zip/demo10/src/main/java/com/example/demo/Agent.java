package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Agent {
	@JsonProperty("AgencyCode")
	private String agencyCode;
	@JsonProperty("AgencyName")
	private String agencyName;
	@JsonProperty("AgentCode")
	private String agentCode;
	@JsonProperty("AgentName")
	private String agentName;
	@JsonProperty("Email")
	private String email;
	@JsonProperty("FaxNumber")
	private String faxNumber;
	@JsonProperty("PhoneNumber")
	private String phoneNumber;
	@JsonProperty("Address")
	private Address address;
	@JsonProperty("AgentType")
	private String agentType;

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getAgentType() {
		return agentType;
	}

	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}

	// Add getter and setter methods

}
