package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.Date;

public class Location {
	@JsonProperty("LookupID")
	private String lookupID;
	@JsonProperty("PolicyNumber")
	private String policyNumber;
	@JsonProperty("RenewalDate")
	private Date renewalDate;
	@JsonProperty("Address")
	private Address address;
	@JsonProperty("Coverages")
	private ArrayList<Coverage> coverages;
	@JsonProperty("Contact")
	private Contact contact;
	@JsonProperty("Name")
	private String name;

	@JsonProperty("PolicyEffectiveDate")
	private Date policyEffectiveDate;

	@JsonProperty("PolicyExpirationDate")
	private Date policyExpirationDate;

	@JsonProperty("PolicyRenewalDate")
	private Date policyRenewalDate;

	@JsonProperty("OriginalEffectiveDate")
	private Date originalEffectiveDate;

	@JsonProperty("EffectiveDate")
	private Date effectiveDate;
	@JsonProperty("ExpirationDate")
	private Date expirationDate;

	@JsonProperty("LastInspectedDate")
	private Date lastInspectedDate;
	public ArrayList<GenericField> genericFields;

	public Date getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}

	public void setPolicyEffectiveDate(Date policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}

	public Date getPolicyExpirationDate() {
		return policyExpirationDate;
	}

	public void setPolicyExpirationDate(Date policyExpirationDate) {
		this.policyExpirationDate = policyExpirationDate;
	}

	public Date getPolicyRenewalDate() {
		return policyRenewalDate;
	}

	public void setPolicyRenewalDate(Date policyRenewalDate) {
		this.policyRenewalDate = policyRenewalDate;
	}

	public Date getOriginalEffectiveDate() {
		return originalEffectiveDate;
	}

	public void setOriginalEffectiveDate(Date originalEffectiveDate) {
		this.originalEffectiveDate = originalEffectiveDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getLastInspectedDate() {
		return lastInspectedDate;
	}

	public void setLastInspectedDate(Date lastInspectedDate) {
		this.lastInspectedDate = lastInspectedDate;
	}

	public ArrayList<GenericField> getGenericFields() {
		return genericFields;
	}

	public void setGenericFields(ArrayList<GenericField> genericFields) {
		this.genericFields = genericFields;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLookupID() {
		return lookupID;
	}

	public void setLookupID(String lookupID) {
		this.lookupID = lookupID;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public ArrayList<Coverage> getCoverages() {
		return coverages;
	}

	public void setCoverages(ArrayList<Coverage> coverages) {
		this.coverages = coverages;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	// Add getter and setter methods

}
