package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;
public class Root {
	@JsonProperty("divisionLookupID")
	private String divisionLookupID;
	@JsonProperty("client")
	private Client client;

	public String getDivisionLookupID() {
		return divisionLookupID;
	}

	public void setDivisionLookupID(String divisionLookupID) {
		this.divisionLookupID = divisionLookupID;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	// Add getter and setter methods

}
