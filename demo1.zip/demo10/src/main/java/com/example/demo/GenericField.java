package com.example.demo;
public class GenericField{
    public String key;
    public String text;
    public int genericFieldValueType;
}
