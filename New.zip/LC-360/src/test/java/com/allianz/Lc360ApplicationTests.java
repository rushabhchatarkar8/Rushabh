package com.allianz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lc360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
