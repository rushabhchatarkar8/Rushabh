package com.allianz.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Passport {

	private Boolean vaccinatinProcessBegun;
	private Boolean VaccinationProcessEnded;
	private Boolean testedNegative;
	private String testDate;
	private Boolean hasBeenSickWithCorona;
	private String vaccineName;
}
