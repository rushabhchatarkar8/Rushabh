package com.allianz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lc360Application {

	public static void main(String[] args) {
		SpringApplication.run(Lc360Application.class, args);
	}

}
