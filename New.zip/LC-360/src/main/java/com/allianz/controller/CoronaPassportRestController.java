package com.allianz.controller;

import java.io.InputStream;
import java.util.Set;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.model.CoronaPassportRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/corona")
@Slf4j
public class CoronaPassportRestController {

	@GetMapping("/home")
	public String demonew() {

		return "Hellow";
	}

	@PostMapping("/novalidation")
	public CoronaPassportRequest createPassport(@RequestBody CoronaPassportRequest request) {
		log.info("Request:" + request);
		return request;
	}

	@PostMapping("/withvalidation")
	public CoronaPassportRequest createPassportValidation(@RequestBody String requestStr)// postman requestStr
			throws JsonProcessingException {
		log.info("Request Json String:" + requestStr);
		InputStream schemaAsStream = CoronaPassportRestController.class.getClassLoader()
				.getResourceAsStream("person.json");
		// wrote schema is store in schemaAsStream
		JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(schemaAsStream);
		// getSchema() : it will get Scema
		// SpecVersion.VersionFlag.V7... draft factory 7 ..is mension in schema file
//		"$schema": "http://json-schema.org/draft-07/schema#",

		ObjectMapper om = new ObjectMapper();

		// using ObjectMapper... creating JSON node

		JsonNode jsonNode = om.readTree(requestStr);

		// Json node passing to validate ()
		// Validate() ... validate the input JSON data with defined JSON data in schema
		Set<ValidationMessage> errors = schema.validate(jsonNode);
//errors .... If there is any error .. it will return Validation message
		/// if no error ... then Set will be empty
		String errorsCombined = "";
		for (ValidationMessage error : errors) {
			log.error("Validation Error: {}", error);
			errorsCombined = error.toString() + "\n";
		}

		if (errors.size() > 0)
			throw new RuntimeException("Please fix your json!" + errorsCombined);

		CoronaPassportRequest request = om.readValue(requestStr, CoronaPassportRequest.class);
		log.info("Return this request:{}", request);
		return request;// it return same request as it is
	}
}
//String jsonSchema = new String(Files.readAllBytes(Paths.get("schema.json")));
//String jsonData = new String(Files.readAllBytes(Paths.get("data.json")));
