/*
 * package com.allianz.controller;
 * 
 * import com.allianz.model.CoronaPassportRequest; import
 * com.github.fge.jsonschema.core.exceptions.ValidationException; import
 * com.github.fge.jsonschema.core.report.ProcessingReport; import
 * com.github.fge.jsonschema.main.JsonSchema; import
 * com.github.fge.jsonschema.main.JsonSchemaFactory;
 * 
 * import java.io.IOException; import java.nio.file.Files; import
 * java.nio.file.Paths;
 * 
 * import org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * @RestController
 * 
 * @RequestMapping("/a") public class SampleController {
 * 
 * @PostMapping("/novalidation")
 * 
 * public reE createPassportValidation(@RequestBody String requestStr)// postman
 * requestStr String jsonSchema = new
 * String(Files.readAllBytes(Paths.get("schema.json"))); String jsonData = new
 * String(Files.readAllBytes(Paths.get("data.json")));
 * 
 * try { JsonSchema schema =
 * JsonSchemaFactory.byDefault().getJsonSchema(jsonSchema); ProcessingReport
 * report = schema.validate(JsonLoader.fromString(jsonData));
 * 
 * if (report.isSuccess()) { System.out.println("JSON data is valid."); } else {
 * System.out.println("JSON data is invalid. Validation errors:");
 * System.out.println(report); } } catch (ValidationException e) {
 * System.out.println("Exception occurred during validation: " +
 * e.getMessage()); } } } }
 * 
 * }
 */